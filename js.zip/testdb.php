<?php
    require 'config\conn_pdo.php';
    $rows = $conn->query('select * from tbluser')->fetchAll();
    echo'<p> เชื่อมต่อสำเร็จ พบผู้ใช้' .count($rows) .'คน</p><ul>';
    foreach ($rows as $r){
        echo '<li>' .htmlspecialchars($r['id'].' '. $r['username']."".$r['firstname']).''.$r['lastname']. '</li>';
    }
?>