<?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $dbname = "dbshop";
    $conn = new mysqli($host,$user,$pass,$dbname);

    
    if($conn->connect_error){
        did("connection failed : ".$conn->connect_error);
    }
    echo"Connection Success";
?>