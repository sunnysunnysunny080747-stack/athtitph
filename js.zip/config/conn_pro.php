<?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $dbname = "dbshop";
    $conn = mysqli_connect($host,$user,$pass,$dbname);

    if(!$conn){
        did("connection failed : ".mysqli_connection_error());
    }
    echo"Connection Success";
?>